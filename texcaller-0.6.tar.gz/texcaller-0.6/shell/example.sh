echo '\documentclass{article}\begin{document}Hello world!\end{document}' >hello.tex
texcaller LaTeX PDF 5 <hello.tex >hello.pdf
