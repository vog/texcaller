latex = r'''
\documentclass{article}
\usepackage{amsmath}
\begin{document} Hello math! \end{document}
'''.decode('utf-8')
