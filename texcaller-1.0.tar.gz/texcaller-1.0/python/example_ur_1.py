latex = ur'''
\documentclass{article}
\u005cusepackage{amsmath}
\begin{document} Hello math! \end{document}
'''
